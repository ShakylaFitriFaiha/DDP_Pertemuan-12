from Animal import Animal

#setiap class child itu memiliki 2 properti dan method
class Ambhibi(Animal) :
    def __init__(self, name, makanan, hidup, berkembang_biak, jenis_air, bernapas):
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.jenis_air = jenis_air
        self.bernapas = bernapas
    def info_amphibi(self) :
        super().info_animal(),
        print(f"Jenis air \t\t\t :", self.jenis_air,
              "\nBernapas \t\t\t :", self.bernapas)
        
amphibi = Ambhibi("Katak", "Serangga", "Dua alam", "Bertelur", "Air Tawar","Kulit dan Paru-Paru" )
amphibi.info_amphibi()

