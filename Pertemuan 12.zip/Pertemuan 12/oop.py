#parents class
class person :
    def __init__(self, nama_depan, nama_belakang):
        self.fname= nama_depan
        self.sname= nama_belakang
    def printname (self) :
        print (f"{self.fname} {self.lname}")
    def jalan(self) :
        print (f"{self.fname} sedang berjalan")

#objek parent
reza = person("Reza", "Maulana")
reza.printname()

class supir (person) :
    pass

#objek child
budi = supir("budi", "sudarsono")
budi.jalan()




