from Animal import Animal

class Karnivora(Animal) :
    def __init__(self, nama, makanan , hidup, berkembang_biak, bernapas, jenis_Gigi, suhu_tubuh) :
        super().__init__(nama, makanan, hidup, berkembang_biak,)
        self.bernapas = bernapas
        self.jenis_Gigi = jenis_Gigi
        self.suhu_tubuh = suhu_tubuh
    
    def info_animal(self):
        super().info_animal(),
        print(f"Bernafas \t\t\t :", self.bernapas, 
              "\nJenis Gigi \t\t\t :", self.jenis_Gigi,
              "\nSuhu Tubuh \t\t\t :", self.suhu_tubuh )
        
Karnivora = Karnivora("Serigala", "Daging", "Darat", "Melahirkan","Paru-Paru", "Taring", "36,5-37,5°C")
Karnivora.info_animal()
