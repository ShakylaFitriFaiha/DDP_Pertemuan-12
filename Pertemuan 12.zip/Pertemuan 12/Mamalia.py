from Animal import Animal

class Mamalia(Animal) :
    def __init__(self, nama, makanan , hidup, berkembang_biak, bernapas, jenis_hewan, ukuran_tubuh, jenis_kulit ) :
        super().__init__(nama, makanan, hidup, berkembang_biak,)
        self.bernapas = bernapas
        self.jenis_hewan = jenis_hewan
        self.ukuran_tubuh = ukuran_tubuh
        self.jenis_kulit = jenis_kulit
    
    def info_animal(self):
        super().info_animal(),
        print(f"Bernafas \t\t\t :", self.bernapas, 
              "\nJenis Hewan \t\t\t :", self.jenis_hewan,
              "\nUkuran Tubuh \t\t\t :", self.ukuran_tubuh,
              "\nJenis Kulis \t\t\t :", self.jenis_kulit)
        
Mamalia = Mamalia("Kucing", "Ikan", "Darat", "Melahirkan","Paru-Paru", "Mamalia Herbivora", "Kecil", "Berbulu")
Mamalia.info_animal()
